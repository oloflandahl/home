/******************************************************************
Lightning Simulator - main.cpp
Olof Landahl, olola361@student.liu.se
2007-01-20
*******************************************************************/

// This program creates a random L-system and simulates it as a lightning
   
/* Keyboard controls:
     Right Shift: generate new lightning  
     Enter: show lightning
     Q: don't show enviroment
     W: show environment
*/

#include <iostream>
#include <exception>
#include "glsl.h"
#include <GL/glfw.h>
#include <GL/glext.h>
#include "camera.h"
#include "lightning.h"
#ifndef PI
#  define PI 3.141592649
#endif

using namespace std;

// Global variables
Camera *c;
Lightning *L;
float t, t0, t_start = 0.0;
int frames = 0;
char titlestring[200];
GLUquadricObj *environment;
bool SHOW_LIGHTNING, GEN_LIGHTNING = GL_FALSE;
bool SHOW_WORLD = GL_TRUE;
bool ANIMATE = GL_TRUE;
bool SHADER_ON = GL_TRUE;
GLFWimage image;


// Cube map
GLuint cubeMap;
GLenum faceTarget[12] = {
GL_TEXTURE_CUBE_MAP_POSITIVE_X_EXT,
GL_TEXTURE_CUBE_MAP_NEGATIVE_X_EXT,
GL_TEXTURE_CUBE_MAP_POSITIVE_Y_EXT,
GL_TEXTURE_CUBE_MAP_NEGATIVE_Y_EXT,
GL_TEXTURE_CUBE_MAP_POSITIVE_Z_EXT,
GL_TEXTURE_CUBE_MAP_NEGATIVE_Z_EXT,

GL_TEXTURE_CUBE_MAP_POSITIVE_X_EXT,
GL_TEXTURE_CUBE_MAP_NEGATIVE_X_EXT,
GL_TEXTURE_CUBE_MAP_POSITIVE_Y_EXT,
GL_TEXTURE_CUBE_MAP_NEGATIVE_Y_EXT,
GL_TEXTURE_CUBE_MAP_POSITIVE_Z_EXT,
GL_TEXTURE_CUBE_MAP_NEGATIVE_Z_EXT
};

// Texture files for the cube map
char *faceFile[12] = {

    "cubemap/dark/autumn_negx.tga",
    "cubemap/dark/autumn_posx.tga",
    "cubemap/dark/autumn_negy.tga",
    "cubemap/dark/autumn_posy.tga",
    "cubemap/dark/autumn_negz.tga",
    "cubemap/dark/autumn_posz.tga",

    "cubemap/light/autumn_negx.tga",
    "cubemap/light/autumn_posx.tga",
    "cubemap/light/autumn_negy.tga",
    "cubemap/light/autumn_posy.tga",
    "cubemap/light/autumn_negz.tga",
    "cubemap/light/autumn_posz.tga"
};

// Function definitions
void initGL();
void showFPS();
void setupCamera();
void renderScene();
void lightWorld(int t);
void drawWorld();


// Set up everything and run the program
int main(int argc, char *argv[]) {

    int running = GL_TRUE; // Main loop exits when this is set to GL_FALSE
    
    // Set the seed for the random function
    srand(time(0));
    
    // Initialise GLFW
    glfwInit();

    // Open the OpenGL window
    if( !glfwOpenWindow(800, 600, 8,8,8,8, 32,0, GLFW_WINDOW) ) {
        glfwTerminate(); // glfwOpenWindow failed, quit the program.
        return 1;
    }

    // Initiate OpenGL
    initGL();    

    // Initiate OpenGL extensions. Part of libglsl
    initGLExtensions();
    
    // Do not wait for screen refresh between frames
    glfwSwapInterval(0);

    // Create a camera
    c = new Camera(0, 0, 0, 90, -90, 800);
    
    // Load and generate cubemap
    glGenTextures(1, &cubeMap);
    glBindTexture(GL_TEXTURE_CUBE_MAP_EXT, cubeMap);
	
    // Mipmapping stuff
    glTexParameteri(GL_TEXTURE_CUBE_MAP_ARB, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_CUBE_MAP_ARB, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_CUBE_MAP_ARB, GL_GENERATE_MIPMAP_SGIS, GL_TRUE);
	
    // Light up the scene
    lightWorld(0);
    
    // Create a lightning object an generate a new lightning l-system
    L = new Lightning();
    L->generateLightning(0.0, 600.0, 1000.0);
 
    // Initialize some variables used in the while loop
    float rnd_number, x_start, z_start;

    cout << "\nLightning Simulator is running\n" << endl;

    // Main loop
    while(running) {
          
        // Calculate and update the frames per second (FPS) display
        showFPS();

        // Clear the color buffer and the depth buffer.
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
 
        // Set up the camera projection.
        setupCamera();
        
        // Right shift button is pressed - generate a new lightning
        if(glfwGetKey(GLFW_KEY_RSHIFT) && GEN_LIGHTNING) {
          lightWorld(0);
          SHOW_LIGHTNING = GL_FALSE;
          L->Del();
          rnd_number = rand()%2000 - 1000.0;
          x_start = rnd_number;
          rnd_number = rand()%2000 - 1000.0;
          z_start = 1000.0 + rnd_number;
          L->generateLightning(x_start, 600.0, z_start);
          GEN_LIGHTNING = GL_FALSE;
          cout << "New lightning was created\n" << endl;
        } 
        
        // Enter button is pressed - show the current lightning and light the scene
        if(glfwGetKey(GLFW_KEY_ENTER)) {
          t_start = t;
          SHOW_LIGHTNING = GL_TRUE;
          lightWorld(1);                                                        
        }
        
        // W button is pressed - show the environment
        if(glfwGetKey('W') && !SHOW_WORLD) {
          SHOW_WORLD = GL_TRUE;
          cout << "World: ON\n" << endl;
          }

        // Q button is pressed - don't show the environment
        if(glfwGetKey('Q') && SHOW_WORLD) {
          SHOW_WORLD = GL_FALSE;
          cout << "World: OFF\n" << endl;
          }

        // S button is pressed - turn on the shader
        if(glfwGetKey('S') && !SHADER_ON) {
          L->turnShaderOn();
          SHADER_ON = GL_TRUE;
          cout << "Shader: ON\n" << endl;
          }

        // A button is pressed - turn off the shader
        if(glfwGetKey('A') && SHADER_ON) {
          L->turnShaderOff();
          SHADER_ON = GL_FALSE;
          cout << "Shader: OFF\n" << endl;
          }

       // X button is pressed - turn on lightning animation
        if(glfwGetKey('X') && !ANIMATE) {
          ANIMATE = GL_TRUE;
          L->setAnimation(1);
          cout << "Animation: ON\n" << endl;

        }

        // Z button is pressed - turn off lightning animation
        if(glfwGetKey('Z') && ANIMATE)  {
          ANIMATE = GL_FALSE;
          L->setAnimation(0);
          cout << "Animation: OFF\n" << endl;
        }

        // Only show the lightning for one second
        int t_delta = (int)(100.0*t-100.0*t_start);
        if( t_delta > 100 && t_delta < 110 && ANIMATE) {
          SHOW_LIGHTNING = GL_FALSE;
          lightWorld(0);             
        }

        // Draw the scene.
        renderScene();
    
        // Swap buffers, i.e. display the image and prepare for next frame.
        glfwSwapBuffers();

        // Check if the ESC key was pressed or the window was closed.
        if(glfwGetKey(GLFW_KEY_ESC) || !glfwGetWindowParam(GLFW_OPENED))
          running = GL_FALSE;
        
    }

    // Close the OpenGL window and terminate GLFW.
    glfwTerminate();

    return 0;
}


// Initiate OpenGL
void initGL() {

    // Enable Z buffering
    glEnable(GL_DEPTH_TEST);
    
    // Initializing environment object
    environment = gluNewQuadric();
    
    // Generate texture coordinates for the environment
    gluQuadricTexture(environment, GL_TRUE);
}


// Calculate frames per second and show it in the title bar
void showFPS() {

    double fps;
    
    // Get current time
    t = glfwGetTime();  // Gets number of seconds since glfwInit()
  
    // If one second has passed, or if this is the very first frame
    if( (t-t0) > 1.0 || frames == 0 )
    {
        fps = (double)frames / (t-t0);

        sprintf(titlestring, "LIGHTNING %.1f FPS", fps);

        glfwSetWindowTitle(titlestring);
        t0 = t;
        frames = 0;
    }
    frames ++;
}


// Set up the OpenGL projection
void setupCamera() {

    int width, height;
    
    // Get window size. It may start out different from the requested
    // size, and will change if the user resizes the window.
    glfwGetWindowSize( &width, &height );
    
    // Safeguard against iconified/closed window
    if(height<=0) 
        height=1;

    // Set viewport
    glViewport( 0, 0, width, height );

    // Select and setup the projection matrix.
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    
    // Setting up fov and clipping plane
    gluPerspective( 65.0f, (GLfloat)width/(GLfloat)height, 1.0f, 4000.0f );
}


// Lights up the scene (switches textures for the cube map)
void lightWorld(int t) {

    for(int i = t*6; i < t*6+6; i++)
    {
    glfwReadImage(faceFile[i], &image,GLFW_NO_RESCALE_BIT);
    glTexImage2D(faceTarget[i], 0, 3, image.Width, image.Height, 0,
      image.Format, GL_UNSIGNED_BYTE, image.Data);
    glfwFreeImage(&image);
    }               
    
    // Removes edges around the cube map
	glTexParameteri(GL_TEXTURE_CUBE_MAP_ARB, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_CUBE_MAP_ARB, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_CUBE_MAP_ARB, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
          
    GEN_LIGHTNING = true;       
}

// Draw the environment (cube map)
void drawWorld() {
	
    glPushMatrix();

    // Enable textures
	glBindTexture(GL_TEXTURE_CUBE_MAP_ARB, cubeMap);
	glEnable(GL_TEXTURE_CUBE_MAP_ARB);

	// Generate texture coordinates
	float xPlane[]={1.0f, 0.0f, 0.0f, 0.0f};
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGenfv(GL_S, GL_OBJECT_PLANE, xPlane);
	glEnable(GL_TEXTURE_GEN_S);
	float yPlane[]={0.0f, 1.0f, 0.0f, 0.0f};
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGenfv(GL_T, GL_OBJECT_PLANE, yPlane);
	glEnable(GL_TEXTURE_GEN_T);
	float zPlane[]={0.0f, 0.0f, 1.0f, 0.0f};
	glTexGeni(GL_R, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGenfv(GL_R, GL_OBJECT_PLANE, zPlane);
	glEnable(GL_TEXTURE_GEN_R);
    glRotatef(180,1,0,0);

    // Rotate it
    gluSphere(environment, 800.0f, 20, 10);

    // Clear depth-buffer bit
    glClear(GL_DEPTH_BUFFER_BIT);
    glPopMatrix();
    glDisable(GL_TEXTURE_GEN_R);
    glDisable(GL_TEXTURE_GEN_T);
    glDisable(GL_TEXTURE_GEN_S);
    glDisable(GL_TEXTURE_CUBE_MAP_ARB);     
}


// Render lightning and environment
void renderScene() { 

    // Change to modleview matrix
    glMatrixMode( GL_MODELVIEW ); 

    // Reset the matrix to identity
    glLoadIdentity();

    // Update tha camera projection
    c->Update();

    // Set blend mode and use anti-aliasing 
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDisable(GL_BLEND);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_POINT_SMOOTH);

    // Render the environment
    if (SHOW_WORLD)
       drawWorld();
    
    // Enable blending (to make use of alpha channel) and render the lightning
    if(SHOW_LIGHTNING) {
      glEnable(GL_BLEND);
      L->drawLightning(t, t_start);
    }

}
