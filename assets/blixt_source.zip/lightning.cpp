/******************************************************************
Lightning Simulator - lightning.cpp
Olof Landahl, olola361@student.liu.se
2007-01-20
*******************************************************************/

// Creates the lightning by building several branches (L-systems) together


#include "lightning.h"

#ifndef PI
#  define PI 3.141592649
#endif

using namespace std;


// Constructor
Lightning::Lightning() {

  //Initialize a shader
  lightningShader = shaderManager.loadfromFile("lightning.vert","lightning.frag");

  SHADER_ON = GL_TRUE;
  set_animation = 1;

  k = 15.0;
}


// Destructor
Lightning::~Lightning() {
  Del();
}

// Clean up memory allocation
void Lightning::Del() {
  seg.clear();
  seg_final.clear();
  lightning->Del();
}


// Generate a lightning with specific start point
void Lightning::generateLightning(float xin, float yin, float zin) {
  z = zin;
  lightning = new Lsystem(xin, yin);
  lightning->buildLightning();
  seg = lightning->getSegments();
  dist = getMaxDistance();

  unsigned int i;
  int count = 0;

  // Change thickness of polygon depending on which branch is generated
  for (i = 0; i < seg.size(); i++) {
        
      if(count < 1)
          k = 15.0;
      else if (count < 4)
          k = 10.0;
      else
          k = 8.0;
                  
      if (seg[i] == 1000.0) {
        i++;
        SHRINK = false;
        seg_final.push_back(1000.0);
    
  // FIRST QUAD
  // Line coordinates for lightning segments (current and next)      
   float x1 = seg[i], y1 = seg[i+1];
   float x2 = seg[i+2], y2 = seg[i+3];
   float x1_next = seg[i+4], y1_next = seg[i+5];
   float x2_next = seg[i+6], y2_next = seg[i+7];
		
   theta = PI/2;
   theta_next = PI/2;
		
   // Vertice 1
   x = x1 + k*cos(theta+PI/2);
   y = y1 + k*sin(theta+PI/2);
   seg_final.push_back(x);
   seg_final.push_back(y);
	    
   // Vertice 2
   x = x1 + k*cos(theta-PI/2);
   y = y1 + k*sin(theta-PI/2);
   seg_final.push_back(x);
   seg_final.push_back(y);
	    
   // Vertice 3
   x_this = x2 + k*cos(theta+PI/2);
   y_this = y2 + k*sin(theta+PI/2);
   x_next = x2_next + k*cos(theta_next+PI/2);
   y_next = y2_next + k*sin(theta_next+PI/2);
   x = (x_this+x_next)/2;
   y = (y_this+y_next)/2;
   seg_final.push_back(x);
   seg_final.push_back(y);
	    
   float x_save_1 = x;
   float y_save_1 = y;
	    
   // Vertice 4
   x_this = x2 + k*cos(theta-PI/2);
   y_this = y2 + k*sin(theta-PI/2);
   x_next = x2_next + k*cos(theta_next-PI/2);
   y_next = y2_next + k*sin(theta_next-PI/2);
   x = (x_this+x_next)/2;
   y = (y_this+y_next)/2;
   seg_final.push_back(x);
   seg_final.push_back(y);
	    
   float x_save_2 = x;
   float y_save_2 = y;
	    
   i+=4;

   // THE REST OF THE QUADS
   while ( seg[i+4] != 1000.0 && i+4 != seg.size() ) {
          
     if (seg[i+80] == 1000.0 || i > seg.size()-80)
        SHRINK = true;       

     if (SHRINK)
        k-=0.3;
        
     x1 = seg[i], y1 = seg[i+1];
	 x2 = seg[i+2], y2 = seg[i+3];
	 x1_next = seg[i+4], y1_next = seg[i+5];
	 x2_next = seg[i+6], y2_next = seg[i+7];

     theta = PI/2;
     theta_next = PI/2;

	 // Vertice 3
	 x_this = x2 + k*cos(theta+PI/2);
	 y_this = y2 + k*sin(theta+PI/2);
	 x_next = x2_next + k*cos(theta_next+PI/2);
	 y_next = y2_next + k*sin(theta_next+PI/2);
	 if(theta == theta_next) {
       x = (x_this+x_next)/2;
	   y = (y_this+y_next)/2;
     }
     else {
       x = x_this;
       y = y_this;
     }
	 seg_final.push_back(x);
     seg_final.push_back(y);
	    
	 x_save_1 = x;
	 y_save_1 = y;
	    
	 // Vertice 4
	 x_this = x2 + k*cos(theta-PI/2);
	 y_this = y2 + k*sin(theta-PI/2);
	 x_next = x2_next + k*cos(theta_next-PI/2);
	 y_next = y2_next + k*sin(theta_next-PI/2);
	 if(theta == theta_next) {
       x = (x_this+x_next)/2;
	   y = (y_this+y_next)/2;
     }
     else {
       x = x_this;
       y = y_this;
     }
	 seg_final.push_back(x);
     seg_final.push_back(y);
	    
	 x_save_2 = x;
	 y_save_2 = y;
	    
	 i+=4;
   }
        
   // LAST QUAD
   x1 = seg[i], y1 = seg[i+1];
   x2 = seg[i+2], y2 = seg[i+3];
		
   theta = PI/2;

   // Vertice 3
   x_this = x2 + k*cos(theta+PI/2);
   y_this = y2 + k*sin(theta+PI/2);
   x = x_this;
   y = y_this;
   seg_final.push_back(x);
   seg_final.push_back(y);
	    
   // Vertice 4
   x_this = x2 + k*cos(theta-PI/2);
   y_this = y2 + k*sin(theta-PI/2);
   x = x_this;
   y = y_this;
   seg_final.push_back(x);
   seg_final.push_back(y);
	    
   i+=3;
   count++;
   }       
  }  
}

// Turn on the shader
void Lightning::turnShaderOn() {
  SHADER_ON = GL_TRUE;
}

// Turn off the shader
void Lightning::turnShaderOff() {
  SHADER_ON = GL_FALSE;
}

// Turn animation on or off
void Lightning::setAnimation(GLint a) {
  set_animation = a;
}


// Generate the lightning polygons and use shaders
void Lightning::drawLightning(float t, float t_start) { 

  unsigned int i;
    
  // Lightning Texture    
  glEnable(GL_TEXTURE_1D);
    
  // Saftey if glsl compiler fails
  if (lightningShader==0)
      cout << "Error Loading, compiling or linking shader\n";
  else if (SHADER_ON)
  {
      // Send variable to the shader
      lightningShader->begin();
      lightningShader->setUniform1f("time", t);
      lightningShader->setUniform1f("t_start", t_start);
      lightningShader->setUniform1f("x", x_start);
      lightningShader->setUniform1f("max_distance", dist);
      lightningShader->setUniform1i("set_animation", set_animation);
  }

  // Change thickness of polygon depending on which branch is generated
  for (i = 0; i < seg_final.size(); i++) {
        
      if (seg_final[i] == 1000.0) {
        i++;
        glBegin(GL_QUAD_STRIP);
		
   // Vertice 1
   x = seg_final[i];
   y = seg_final[i+1];
   glTexCoord1f(0.0);
   glVertex3f(x, y, z);
	    
   // Vertice 2
   x = seg_final[i+2];
   y = seg_final[i+3];
   glTexCoord1f(1.0);
   glVertex3f(x, y, z);
	    
   // Vertice 3
   x = seg_final[i+4];
   y = seg_final[i+5];
   glTexCoord1f(0.0);
   glVertex3f(x, y, z);
	    
   // Vertice 4
   x = seg_final[i+6];
   y = seg_final[i+7];
   glTexCoord1f(1.0);
   glVertex3f(x, y, z); 
	    
   i+=8;

   // THE REST OF THE QUADS
   while ( seg_final[i+4] != 1000.0 && i+4 != seg_final.size() ) {
        
     // Vertice 3  
     x = seg_final[i];
     y = seg_final[i+1];
	 glTexCoord1f(0.0);
	 glVertex3f(x, y, z);  
	    
	 // Vertice 4
	 x = seg_final[i+2];
     y = seg_final[i+3];
	 glTexCoord1f(1.0);
	 glVertex3f(x, y, z);
	    
	 i+=4;
   }
        
   // LAST QUAD

   // Vertice 3
   x = seg_final[i];
   y = seg_final[i+1];
   glTexCoord1f(0.0);
   glVertex3f(x, y, z);
	    
   // Vertice 4
   x = seg_final[i+2];
   y = seg_final[i+3];
   glTexCoord1f(1.0);
   glVertex3f(x, y, z);
	    
   i+=3;
	    
   glEnd();
      }
        
  glFinish();        
  }  
    
  // Turn shader off
  lightningShader->end();

  glDisable(GL_TEXTURE_1D);
}

// Find the maximum distance from the end of a branch to the start point
// (used to normalise the distance in the shader) 
float Lightning::getMaxDistance() {

  float dist, max_dist = 0.0;
      
  for (unsigned int i=0; i < seg.size(); i+=4) {
    if (seg[i] != 1000.0) {
      dist = sqrt(pow(seg[i+1]-600.0, 2) + pow(seg[i]-0.0, 2));
      if (dist > max_dist)
        max_dist = dist;
    }
    else
      i-=3;   
  }
      
  return max_dist;
  cout << max_dist << endl;      
}
