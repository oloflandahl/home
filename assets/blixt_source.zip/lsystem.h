/******************************************************************
Lightning Simulator - lsystem.h
Olof Landahl, olola361@student.liu.se
2007-01-20
*******************************************************************/


#ifndef _LSYSTEM_H_
#define _LSYSTEM_H_

#include "branch.h"

class Lsystem
{
public:
	Lsystem();
	Lsystem(float xin, float yin);
	~Lsystem();
	void Del();

	void buildLightning();
	vector<float> getSegments();

private:
	float a[3];
	float x_start, y_start;
	vector<Branch*> branches;
	vector<float> seg;

	void addSegments(vector<float> branch_segments);
};

#endif
