/******************************************************************
Lightning Simulator - camera.cpp
Olof Landahl, olola361@student.liu.se
2007-01-20
*******************************************************************/

// Creates and handles a simple camera


#include "camera.h"


// Constructor
Camera::Camera(float x, float y, float z, float t, float p, float d)
{
    viewPosX = x;
    viewPosY = y;
    viewPosZ = z;
    phi = p;
    theta = t;
    distance = d;

    eyePosX = distance * cos(theta*M_PI/180) * sin((90-phi)*M_PI/180) + viewPosX;
    eyePosY = distance * sin(theta*M_PI/180) * sin((90-phi)*M_PI/180) + viewPosY;
    eyePosZ = distance * cos((90-phi)*M_PI/180) + viewPosZ;

}


// Update camera
void Camera::Update()
{
 
    gluLookAt(eyePosX, eyePosY, eyePosZ,
                viewPosX, viewPosY, viewPosZ,
                0, 0, 1);
}


// Rotate camera
void Camera::ChangeTheta(float degrees)
{
    theta += degrees;
    if(theta > 360)
        theta -= 360;
    if(theta < 0);
        theta += 360;

    eyePosX = distance * cos(theta*M_PI/180) * sin((90-phi)*M_PI/180) + viewPosX;
    eyePosY = distance * sin(theta*M_PI/180) * sin((90-phi)*M_PI/180) + viewPosY;
    eyePosZ = distance * cos((90-phi)*M_PI/180) + viewPosZ;

} 


// Rotate camera
void Camera::ChangePhi(float degrees)
{
    phi += degrees;
    if(phi > 90)
        phi = 89.9;
    if(phi <  -90)
        phi = -89.9;

    eyePosX = distance * cos(theta*M_PI/180) * sin((90-phi)*M_PI/180) + viewPosX;
    eyePosY = distance * sin(theta*M_PI/180) * sin((90-phi)*M_PI/180) + viewPosY;
    eyePosZ = distance * cos((90-phi)*M_PI/180) + viewPosZ;

}


// Move camera
void Camera::ChangeDist(float dist)
{
    distance += dist;
    if(distance < 1)
        distance = 1;

    eyePosX = distance * cos(theta*M_PI/180) * sin((90-phi)*M_PI/180) + viewPosX;
    eyePosY = distance * sin(theta*M_PI/180) * sin((90-phi)*M_PI/180) + viewPosY;
    eyePosZ = distance * cos((90-phi)*M_PI/180) + viewPosZ;
}


// Move camera
void Camera::ChangeView(float x, float y, float z)
{
    viewPosX += x;
    viewPosY += y;
    viewPosZ += z;
    
    eyePosX = distance * cos(theta*M_PI/180) * sin((90-phi)*M_PI/180) + viewPosX;
    eyePosY = distance * sin(theta*M_PI/180) * sin((90-phi)*M_PI/180) + viewPosY;
    eyePosZ = distance * cos((90-phi)*M_PI/180) + viewPosZ;
}
