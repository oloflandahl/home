#ifndef _BRANCH_H_
#define _BRANCH_H_

#include <iostream>
/******************************************************************
Lightning Simulator - branch.h
Olof Landahl, olola361@student.liu.se
2007-01-20
*******************************************************************/


#include <stdio.h>
#include <map>
#include <string>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <math.h>

using namespace std;

typedef std::map<string, string> LSystemRules;


class Branch : LSystemRules {
      
	public:
      Branch(int it, float ix, float iy, float iangle, float langle);
	  ~Branch();
	  void Del();
      void reset();
      void translate();
      string iterate();
	  string randomizer(int it);
	  float getPosition(int p);
	  float getAngle();
   	  void print();
	  void addSegment(float x1, float y1, float x2, float y2);
	  vector<float> getSegments();
	  
	private:
	  string start;
	  string cur_string;

	  int count_branch;
	  int iterations;
	  float pos[9];
	  float x, y;
	  float angle, limitangle;
	  vector<float> segments;

	  void forward(int delta);
	  void right(int dangle);
	  void left(int dangle);
};
#endif
