/******************************************************************
Lightning Simulator - branch.cpp
Olof Landahl, olola361@student.liu.se
2007-01-20
*******************************************************************/

// Define and implement the L-system language as a branch


#include "branch.h"
#include <cmath>
#define PI 3.14159265

using namespace std;


// Constructor
Branch::Branch(int it, float ix, float iy, float iangle, float langle) : start("F"), cur_string("F") {                  
	
  segments.push_back(1000.0);
  x = ix;
  y = iy;
  angle = iangle;
  limitangle = langle;
  iterations = it;

  count_branch = 0;
  (*this)["F"] = randomizer(it); 
}


// Destructor
Branch::~Branch() {
  Del();
}


// Clean up memory allocation
void Branch::Del() {
  delete[] pos;
  segments.clear();          
}


// Translate the L-system language to positions and angles
void Branch::translate() {
  for (unsigned int i = 0; i < cur_string.size(); i++) {
    switch (cur_string[i]) {
      case 'F':
      forward(5);			// Move forward
      break;
      case '+':
      left(30);				// Turn left
      break;
      case '-':
      right(30);			// Turn right
      break;

	  case 'b':						
	    if(count_branch < 4-iterations) {	// Add branch (store position and angle)
	      pos[3*count_branch] = x;
		  pos[3*count_branch+1] = y;
	      pos[3*count_branch+2] = angle;
		  count_branch++;
		}
      break;

      case 'p':
	  print();				// Print position and angle
      break;						
    }
  }
}


// Iterate through the L-system language
string Branch::iterate() {
  
  string next_string;
  
  for (unsigned int j = 0; j < cur_string.size(); j++) {
    string k = cur_string.substr(j, 1);
    std::map<string, string>::iterator ix = find(k);
    if (ix != end()) {
	  k = (*ix).second;
    }
    next_string += k;
  }
  cur_string = next_string;
  next_string = "";
  
  return cur_string;
}


// Reset the L-system
void Branch::reset() {
  cur_string = start;
}


// Create a random branch
string Branch::randomizer(int it) {
	
  string final_string;
  float random_nr;
  int count_turns = 0;
  int count_F = 0;
  int count_since_branch = 0;
  int max;
  string temp_string;

  if(it == 3) {
    count_branch = 3;
	max = 30;
  }
  else
	max = 200/it;
		
  // Add another character in each loop
  while(count_turns < max) {

	// Create a random number between 0 and 1
	random_nr = (rand()%100)/100.0;
		
	// Choose a character, depending on the random number
	if (random_nr < 0.5 && count_F > 30/(it*it) && count_since_branch > 50-10*it) {
      temp_string = "b";
	  count_since_branch = 0;
	}
	else if (random_nr >= 0.7 && random_nr < 0.85 && temp_string != "-" && temp_string != "+") temp_string = "-";
	else if (random_nr >= 0.85 && random_nr < 1.0 && temp_string != "-" && temp_string != "+") temp_string = "+";
	else {
	  temp_string = "F";
	  count_turns++;
	  count_F++;
	  count_since_branch++;
	}

	final_string.append(temp_string);	// Add the character to the L-system string
  }
	
	return final_string;				// Return the final L-system string
}


// Move one position forward in the current direction
void Branch::forward(int delta) {	
  // Control the direction of the line
  if(angle < limitangle-70 || angle > limitangle+70)
	angle = limitangle;
	  
  if(angle < -150)
    angle = -160;
  else if (angle > -30)
    angle = -20;

  // Calculate angle in radians
  float radians = (2 * PI) * (angle / 360.0);

  // Calculate amount of x and y movement
  float dx = cosf(radians);
  float dy = sinf(radians);
  
  // Assign to zero if too small
  if (fabs(dx) < 0.00001) dx = 0.0f;
  if (fabs(dy) < 0.00001) dy = 0.0f;

  // Calculate the distance in x and y
  dx *= delta;
  dy *= delta;

  // If not under 'ground-level', add the line-segment
  if(y > -400)								
	addSegment(x, y, x+dx, y+dy);
		
  // Update positions
  x += dx;						
  y += dy;						
}


// Turn to the right
void Branch::right(int dangle) {
  angle -= dangle;
}


// Turn to the left
void Branch::left(int dangle) {
  angle += dangle;
}


// Returns the current position
float Branch::getPosition(int p) {
  return pos[p];
}


// Returns the current angle (direction)
float Branch::getAngle() {
  return angle;
}


// Print the current position and angle
void Branch::print() {
  float temp = angle + 90;
  printf("x = %f, y = %f, angle = %f\n",x,y,temp);
}										


// Add a segment to the canvas
void Branch::addSegment(float x1, float y1, float x2, float y2) {
  segments.push_back(x1);
  segments.push_back(y1);
  segments.push_back(x2);
  segments.push_back(y2);
}


// Returns the segment vector for the branch
vector<float> Branch::getSegments() {
  return segments;
}
