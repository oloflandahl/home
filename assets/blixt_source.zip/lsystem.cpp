/******************************************************************
Lightning Simulator - lsystem.cpp
Olof Landahl, olola361@student.liu.se
2007-01-20
*******************************************************************/

// Creates the lightning by building several branches (L-systems) together


#include "lsystem.h"

using namespace std;


// Default Constructor
Lsystem::Lsystem(){
  x_start = 0.0;
  y_start = 600.0;
}


// Constructor (with specific start coordinates)
Lsystem::Lsystem(float xin, float yin){
  x_start = xin;
  y_start = yin;
}

// Destructor
Lsystem::~Lsystem(){
  Del();
}


// Clean up memory allocation
void Lsystem::Del() {
  delete[] a;
  for (unsigned int i=0; i < branches.size(); i++)
    branches[i]->Del();
    branches.clear();
    seg.clear();
}


// Create the lightning by adding branches and save all segments in a vector
void Lsystem::buildLightning() {

  // Create L-systems
  Branch* main_branch = new Branch(1, x_start, y_start, -90.0, -90.0);
  branches.push_back(main_branch);
	
  // Reset, iterate and add the main branch
  main_branch->reset();
  main_branch->iterate();
  main_branch->translate();
  addSegments(main_branch->getSegments());

  // Reset, iterate and add branches to the main branch
  for (int i = 0; i < 3; i++) {

    int it = 2;
	float ix = main_branch->getPosition(3*i);
	float iy = main_branch->getPosition(3*i+1);
	float iangle = main_branch->getPosition(3*i+2);
	float langle;
	if (iangle > -90) {
	  iangle = iangle-60;
      langle = -120.0;
	}
	else {
	  iangle = iangle+60;
	  langle = -60.0;
	}
	Branch* temp_branch = new Branch(it, ix, iy, iangle, langle);
	branches.push_back(temp_branch);

    temp_branch->reset();
	temp_branch->iterate();
	temp_branch->translate();
	addSegments(temp_branch->getSegments());
    temp_branch->Del();

	a[i] = langle;
  }
	
  // Reset, iterate and add branches to the branches
  for (int i = 0; i < 3; i++) {

	int it = 3;
	Branch* parent_branch = branches[i+1];
            
	for (int j = 0; j < 2; j++) {
            
	  float ix = parent_branch->getPosition(3*j);
	  float iy = parent_branch->getPosition(3*j+1);
	  float iangle = parent_branch->getPosition(3*j+2);
	  float langle;
	  if (iangle > -90) {
		iangle = iangle-60;
		langle = -120.0;
	  }
	  else {
		iangle = iangle+60;
		langle = -60.0;
	  }
      Branch* temp_branch = new Branch(it, ix, iy, iangle, langle);
	  branches.push_back(temp_branch);

      temp_branch->reset();
	  temp_branch->iterate();
	  temp_branch->translate();
	  addSegments(temp_branch->getSegments());
	  temp_branch->Del();
		
	  if (i == 2)
        j = 2;
      }
      parent_branch->Del();
	}
	main_branch->Del();
}


// Add segments from a branch vector to the lightning segments vector
void Lsystem::addSegments(vector<float> branch_segments) {
  for (unsigned int i=0; i < branch_segments.size(); i++)
    seg.push_back(branch_segments[i]);
}


// Return all segments of the lightning
vector<float> Lsystem::getSegments() {
  return seg;
}
