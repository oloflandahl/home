/******************************************************************
Lightning Simulator - lightning.h
Olof Landahl, olola361@student.liu.se
2007-01-20
*******************************************************************/


#ifndef _LIGHTNING_H_
#define _LIGHTNING_H_

#include "glsl.h"
#include <GL/glfw.h>
#include <GL/glext.h>
#include "lsystem.h"

class Lightning
{
public:
	Lightning();
	~Lightning();
	void Del();

    void generateLightning(float xin, float yin, float zin);
	void drawLightning(float t, float t_start);
    float getMaxDistance();
    void turnShaderOn();
    void turnShaderOff();
    void setAnimation(GLint a);
    
private:
    static GLubyte lightning_image[9][3];
    vector<float> seg;
    vector<float> seg_final;
    GLfloat x, y, z;
    GLint set_animation;
    float dist;
    float x_start, y_start;
    float x_this, y_this, x_next, y_next, theta, theta_next, k;
    Lsystem *lightning;
       
    bool SHADER_ON, SHRINK;
    glShaderManager shaderManager;
    glShader *lightningShader;
};

#endif
