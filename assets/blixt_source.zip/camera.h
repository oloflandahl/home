/******************************************************************
Lightning Simulator - camera.h
Olof Landahl, olola361@student.liu.se
2007-01-20
*******************************************************************/


#ifndef CAMERA_H
#define CAMERA_H

#include <math.h>
#include <GL/glu.h>

class Camera
{
    public:
        // x, y, z, phi, theta, distance
        Camera(float, float, float, float, float, float);
        void Update();
        void ChangeTheta(float);
        void ChangePhi(float);
        void ChangeDist(float);
        void ChangeView(float, float, float);
        
        float GetPosX() { return eyePosX;};
        float GetPosY() { return eyePosY;};
        float GetPosZ() { return eyePosZ;};
        float GetViewPosX() { return viewPosX;};
        float GetViewPosY() { return viewPosY;};
        float GetViewPosZ() { return viewPosZ;};
        float GetPhi() { return phi; }
        float GetTheta() { return theta; }
        
    private:
        float viewPosX, viewPosY, viewPosZ;
        float eyePosX, eyePosY, eyePosZ;
        float distance, phi, theta;
};

#endif
